package com.example.bacstudy

import android.app.*
import android.os.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Subject(val name:String,val coef:Int,var level:Int)

class MainActivity:Activity(){
 private lateinit var content:LinearLayout
 private val p by lazy{getSharedPreferences("bac2",MODE_PRIVATE)}
 private val subjects=mutableListOf(
  Subject("الرياضيات",5,3),Subject("الفيزياء",5,3),Subject("الهندسة الكهربائية",6,3),
  Subject("العربية",3,2),Subject("الفرنسية",2,2),Subject("الإنجليزية",2,2),Subject("الفلسفة",2,1)
 )
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}

 private fun page(title:String){
  val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setBackgroundColor(0xFFF5F7FA.toInt())
  val bar=TextView(this);bar.text=title;bar.textSize=22f;bar.setTextColor(Color.WHITE);bar.gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT
  bar.setPadding(22,0,22,0);bar.setBackgroundColor(0xFF1565C0.toInt());root.addView(bar,LinearLayout.LayoutParams(-1,64))
  content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(16,14,16,20)
  val sc=ScrollView(this);sc.addView(content);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
 }
 private fun t(s:String,z:Float=17f)=TextView(this).apply{text=s;textSize=z;setTextColor(0xFF202124.toInt());setPadding(4,9,4,9)}
 private fun b(s:String,fn:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{fn()}}
 private fun home(){
  page("BacStudy — خطتك للبكالوريا")
  content.addView(t("مرحبًا 👋",27f))
  content.addView(t("مساعدك لتنظيم الفهم والحفظ والتمارين والمراجعة.",17f))
  val target=p.getInt("daily",5); val done=p.getInt("done",0)
  content.addView(t("اليوم: ${SimpleDateFormat("EEEE، d MMMM",Locale("ar")).format(Date())}"))
  content.addView(t("إنجاز اليوم: $done / $target جلسات",20f))
  val pb=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.max=target;pb.progress=done;content.addView(pb)
  content.addView(b("🚀 خطة اليوم الذكية"){today()})
  content.addView(b("📅 الخطة الأسبوعية"){week()})
  content.addView(b("📚 المواد والأولوية"){subjectsPage()})
  content.addView(b("🧠 المراجعة المتباعدة"){review()})
  content.addView(b("✍️ المهام والتمارين"){tasks()})
  content.addView(b("⏱️ جلسة تركيز"){timer()})
  content.addView(b("⚙️ إعدادات البرنامج"){settings()})
 }
 private fun today(){
  page("خطة اليوم الذكية")
  val sorted=subjects.sortedByDescending{it.coef*it.level}
  content.addView(t("الخطة تتغير حسب معامل المادة ومستواك الحالي.",16f))
  var time=0
  sorted.take(5).forEachIndexed{i,s->
   val mins=if(i<2)50 else 40
   val type=when(i%3){0->"فهم الدرس";1->"حل تمارين";else->"حفظ ومراجعة"}
   content.addView(t("${8+i*2}:00 – ${8+i*2}:${mins.toString().padStart(2,'0')}  •  ${s.name} — $type",18f))
   val c=CheckBox(this);c.text="أنجزت الجلسة";c.setOnCheckedChangeListener{_,v->if(v){p.edit().putInt("done",p.getInt("done",0)+1).apply()}}
   content.addView(c);time+=mins
  }
  content.addView(t("مجموع الدراسة المركزة المقترح: $time دقيقة."))
  content.addView(b("← الرئيسية"){home()})
 }
 private fun week(){
  page("الخطة الأسبوعية")
  val days=arrayOf("السبت","الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة")
  days.forEachIndexed{i,d->
   val main=subjects.sortedByDescending{it.coef+it.level}.let{it[(i*2)%it.size]}
   val second=subjects.sortedByDescending{it.level}.let{it[(i*2+1)%it.size]}
   content.addView(t("📅 $d",20f));content.addView(t("• ${main.name}: تمارين\n• ${second.name}: فهم + حفظ\n• 20 دقيقة: مراجعة أخطاء اليوم"))
  }
  content.addView(b("← الرئيسية"){home()})
 }
 private fun subjectsPage(){
  page("المواد والأولوية")
  content.addView(t("قيّم مستواك من 1 إلى 5، وسيستخدمه التطبيق في ترتيب الخطة.",16f))
  subjects.forEachIndexed{i,s->
   val row=LinearLayout(this);row.orientation=LinearLayout.VERTICAL
   row.addView(t("${s.name}  • المعامل ${s.coef}",18f))
   val seek=SeekBar(this);seek.max=4;seek.progress=s.level-1
   seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
    override fun onProgressChanged(x:SeekBar?,v:Int,f:Boolean){s.level=v+1;p.edit().putInt("level$i",v+1).apply()}
    override fun onStartTrackingTouch(x:SeekBar?){}
    override fun onStopTrackingTouch(x:SeekBar?){}
   });row.addView(seek);content.addView(row)
  }
  content.addView(b("حفظ التقييمات"){Toast.makeText(this,"تم حفظ مستويات المواد",Toast.LENGTH_SHORT).show()})
  content.addView(b("← الرئيسية"){home()})
 }
 private fun review(){
  page("المراجعة المتباعدة")
  content.addView(t("🔁 نظام 1 → 3 → 7 → 14 يومًا",23f))
  content.addView(t("بعد دراسة أي درس، راجعه بعد يوم، ثم 3 أيام، ثم أسبوع، ثم أسبوعين."))
  subjects.forEach{s->
   val date=p.getString("review_${s.name}","غير محدد")
   content.addView(t("${s.name}: $date"))
   content.addView(b("تسجيل مراجعة اليوم"){p.edit().putString("review_${s.name}", "اليوم • التالي بعد 1 يوم").apply();Toast.makeText(this,"تم تسجيل المراجعة",Toast.LENGTH_SHORT).show()})
  }
  content.addView(b("← الرئيسية"){home()})
 }
 private fun tasks(){
  page("المهام والتمارين")
  val input=EditText(this);input.hint="مثال: حل موضوع بكالوريا 2024 — رياضيات";content.addView(input)
  val spinner=Spinner(this);spinner.adapter=ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,subjects.map{it.name});content.addView(spinner)
  content.addView(b("➕ إضافة المهمة"){
   val n=input.text.toString().trim();if(n.isNotEmpty()){p.edit().putString("task_${System.currentTimeMillis()}","${spinner.selectedItem}: $n").apply();Toast.makeText(this,"تمت إضافة المهمة",Toast.LENGTH_SHORT).show();input.text.clear()}
  })
  content.addView(t("المهام المحفوظة تظهر هنا عند إعادة فتح الصفحة في النسخ القادمة."))
  content.addView(b("← الرئيسية"){home()})
 }
 private fun timer(){
  page("جلسة تركيز")
  val label=t("50:00",48f);label.gravity=Gravity.CENTER;content.addView(label)
  var sec=50*60;var run=false;val h=Handler(Looper.getMainLooper())
  val r=object:Runnable{override fun run(){if(!run)return;sec--;label.text=String.format("%02d:%02d",sec/60,sec%60);if(sec<=0){run=false;p.edit().putInt("done",p.getInt("done",0)+1).apply();Toast.makeText(this@MainActivity,"أحسنت! انتهت الجلسة 🎉",Toast.LENGTH_LONG).show()}else h.postDelayed(this,1000)}}
  content.addView(b("▶ بدء / إيقاف"){run=!run;if(run)h.post(r)})
  content.addView(b("↻ إعادة 50 دقيقة"){run=false;sec=50*60;label.text="50:00"})
  content.addView(b("← الرئيسية"){home()})
 }
 private fun settings(){
  page("إعدادات البرنامج")
  val name=EditText(this);name.hint="اسمك";name.setText(p.getString("name",""));content.addView(name)
  val school=EditText(this);school.hint="وقت المدرسة مثال 08:30 - 15:00";school.setText(p.getString("school","08:30 - 15:00"));content.addView(school)
  val daily=EditText(this);daily.inputType=2;daily.hint="عدد جلسات الدراسة اليومية";daily.setText(p.getInt("daily",5).toString());content.addView(daily)
  content.addView(b("💾 حفظ الإعدادات"){p.edit().putString("name",name.text.toString()).putString("school",school.text.toString()).putInt("daily",daily.text.toString().toIntOrNull()?:5).apply();Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show()})
  content.addView(t("الإعدادات الحالية ستؤثر على الخطة اليومية في الإصدار التالي."))
  content.addView(b("← الرئيسية"){home()})
 }
}