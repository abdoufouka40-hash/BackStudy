# BacStudy — Build APK from GitHub

هذه النسخة مجهزة للبناء عبر GitHub Actions ولا تحتاج إلى Gradle Wrapper.

## الخطوات من الهاتف

1. أنشئ Repository جديدًا على GitHub.
2. ارفع **كل محتويات هذا المجلد** إلى المستودع، وليس ملف ZIP فقط.
3. تأكد أن `.github/workflows/build-apk.yml` موجود.
4. ادخل إلى تبويب **Actions**.
5. اختر **Build BacStudy APK**.
6. اضغط **Run workflow** إذا لم يبدأ البناء تلقائيًا.
7. بعد نجاح العملية، افتح صفحة الـworkflow ثم قسم **Artifacts**.
8. نزّل `BacStudy-APK` وستجد بداخله `app-debug.apk`.

## ملاحظة

الـAPK الناتج Debug APK مناسب للتثبيت والتجربة على الهاتف. للنشر على Google Play يلزم إنشاء نسخة Release موقعة بمفتاح توقيع.
